import React from 'react';
import Home from './Views/Home/home';

function App() {
  return (
   <Home/>
  );
}

export default App;
